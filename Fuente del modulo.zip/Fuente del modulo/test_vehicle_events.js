import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 50,
  iterations: 1000,	
  duration: '30s',
};

export default function () {

  const isEmergency = (__ITER % 20 === 0);

  const payload = JSON.stringify({
    type: isEmergency ? "Emergency" : "Position",
    vehicle_plate: `ABC-${__VU}`,
    coordinates: {
      latitude: 12.345,
      longitude: 67.890
    },
    status: isEmergency ? "PANIC" : "OK"
  });

  const res = http.post(
    'https://utbxd7y7e5.execute-api.us-east-2.amazonaws.com/dev/events',
    payload,
    {
      headers: {
        'Content-Type': 'application/json'
      }
    }
  );

  check(res, {
    'status 200': (r) => r.status === 200
  });

  sleep(1);
}