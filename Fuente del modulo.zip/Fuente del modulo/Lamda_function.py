import json
import boto3
from datetime import datetime, timezone

ses = boto3.client('ses')

EMAIL_FROM = "lucihuerta2512@gmail.com"
EMAIL_TO = "lucihuerta2512@gmail.com"

def lambda_handler(event, context):

    for record in event.get('Records', []):

        try:
            body = json.loads(record['body'])

            # Si el mensaje viene desde SNS → SQS
            if 'Message' in body:
                message = json.loads(body['Message'])
            else:
                message = body

            event_type = message.get('type')
            vehicle_plate = message.get('vehicle_plate', 'SIN_PLACA')

            now = datetime.now(timezone.utc).isoformat()

            print(f"Evento recibido: {now}")
            print(json.dumps(message))

            if event_type == "Emergency":

                response = ses.send_email(
                    Source=EMAIL_FROM,
                    Destination={
                        'ToAddresses': [EMAIL_TO]
                    },
                    Message={
                        'Subject': {
                            'Data': '🚨 Alerta de Emergencia 🚨'
                        },
                        'Body': {
                            'Text': {
                                'Data': f"""
🚨 ALERTA DE EMERGENCIA 🚨

Placa: {vehicle_plate}
Estado: {message.get('status', 'No informado')}
Evento: {event_type}
"""
                            }
                        }
                    }
                )

                print("Correo enviado correctamente")
                print(response)

            else:
                print(f"Evento ignorado: {event_type}")

        except Exception as e:
            print(f"Error procesando mensaje: {str(e)}")
            raise

    return {
        'statusCode': 200,
        'body': 'Mensajes procesados'
    }